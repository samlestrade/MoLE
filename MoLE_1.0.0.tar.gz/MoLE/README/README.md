﻿Model for simulating language evolution in terms of cultural evolution. The focus is on the emergence of argument marking systems (noun marking, person indexing, word order), but extensions are foreseen.

Check/change model parameters in object "world"
Found a population with "FOUND()"
Start a simulation with "RUN()"